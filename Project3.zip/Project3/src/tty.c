#include "stm32f0xx.h"
#include "stm32f0_discovery.h"

#include <stdio.h>
#include <stdarg.h>
#include "headers.h"

#define UNK -1
#define NON_INTR 0
#define INTR 1
int interrupt_mode = UNK;

int __io_putchar(int ch);
static int putchar_nonirq(int ch);
static struct fifo input_fifo;  // input buffer
static struct fifo output_fifo; // output buffer
int echo_mode = 1;              // should we echo input characters?
int line_mode = 1;              // should we wait for a newline?

//=============================================================================
// This is a version of printf() that will disable interrupts for the
// USART and write characters directly.  It is intended to handle fatal
// exceptional conditions.
// It's also an example of how to create a variadic function.
static void safe_printf(const char *format, ...) {
    va_list ap;
    va_start(ap, format);
    char buf[80];
    int len = vsnprintf(buf, sizeof buf, format, ap);
    int saved_txeie = USART1->CR1 & USART_CR1_TXEIE;
    USART1->CR1 &= ~USART_CR1_TXEIE;
    int x;
    for(x=0; x<len; x++) {
        putchar_nonirq(buf[x]);
    }
    USART1->CR1 |= saved_txeie;
    va_end(ap);
}

//=======================================================================
// Simply write a string one char at a time.
//=======================================================================
static void putstr(const char *s) {
    while(*s)
        __io_putchar(*s++);
}

//=======================================================================
// Insert a character and echo it.
// (or, if it's a backspace, remove a char and erase it from the line).
// If echo_mode is turned off, just insert the character and get out.
//=======================================================================
static void insert_echo_char(char ch) {
    if (ch == '\r')
        ch = '\n';
    if (!echo_mode) {
        fifo_insert(&input_fifo, ch);
        return;
    }
    if (ch == '\b' || ch == '\177') {
        if (!fifo_empty(&input_fifo)) {
            char tmp = fifo_uninsert(&input_fifo);
            if (tmp == '\n')
                fifo_insert(&input_fifo, '\n');
            else if (tmp < 32)
                putstr("\b\b  \b\b");
            else
                putstr("\b \b");
        }
        return; // Don't put a backspace into buffer.
    } else if (ch == '\n') {
        __io_putchar('\n');
    } else if (ch == 0){
        putstr("^0");
    } else if (ch == 28) {
        putstr("^\\");
    } else if (ch < 32) {
        __io_putchar('^');
        __io_putchar('A'-1+ch);
    } else {
        __io_putchar(ch);
    }
    fifo_insert(&input_fifo, ch);
}

//=======================================================================
// Enable the USART RXNE interrupt.
// Remember to enable the right bit in the NVIC registers
//=======================================================================
void enable_tty_irq(void) {
    // Student code goes here...
    USART1->CR1 |= USART_CR1_RXNEIE;//Enable RXNE interrupt
    //TIM6->DIER |= TIM_DIER_UIE;//TODO: NEED HERE?
    NVIC->ISER[0] |= (1<<USART1_IRQn);//was TIM6_DAC_IRQn
    //TIM6->CR1 |= TIM_CR1_CEN;//TODO: NEED HERE?
    interrupt_mode = INTR;//TODO: Do this now?
    NVIC_SetPriority(USART1_IRQn,2);//give USART1 high interrupt priority
    //CHANGED USART priority to 2 from 1
    // REMEMBER TO SET THE USART1 INTERRUPT PRIORITY HERE!
}

//=======================================================================
// This method should perform the following
// Transmit 'ch' using USART1, remember to wait for transmission register to be
// empty. Also this function must check if 'ch' is a new line character, if so
// it must transmit a carriage return before transmitting 'ch' using USART1.
// Think about this, why must we add a carriage return, what happens otherwise?
//=======================================================================
static int putchar_nonirq(int ch) {
    // Student code goes here...
    if (ch == '\n') {//Check if 'ch' is a new line char
        while((USART1->ISR & USART_ISR_TXE) !=USART_ISR_TXE) {
            //wait for tx reg to be empty
        }
        USART1->TDR = 0xD;//transmit carriage return
        //__io_putchar(0xD);
    }
    while((USART1->ISR & USART_ISR_TXE) !=USART_ISR_TXE) {
        //wait for tx reg to be empty
    }

    USART1->TDR = ch;//Transmit 'ch'
    //__io_putchar(ch);
    return ch;
}

//-----------------------------------------------------------------------------
// Section 6.4
//-----------------------------------------------------------------------------
// See lab document for description
static int getchar_nonirq(void) {
    // Student code goes here...
    //Feed chars into FIFO.
    //When FIFO read \n, remove chars one at a time
    //Return them to the caller.

    if ((USART1->ISR & USART_ISR_ORE) == USART_ISR_ORE) {//Check for the overrun flag
        USART1->ICR |= USART_ICR_ORECF;//Clear the flag
    }
    if (line_mode == 1) {//check for \n only when line_mode == 1
        while(!fifo_newline(&input_fifo)) {//While input_fifo has no \n
            while((USART1->ISR&USART_ISR_RXNE)!=USART_ISR_RXNE) {
                //Wait for RXNE flag to be set
            }
            char reader = USART1->RDR;//Read char from USART and put input_fifo with insert_echo_char()
            insert_echo_char(reader);
        }
    }//TODO: DO I MOVE ALL THE THINGS IN WHILE?
    else {//I added this... TODO: do I need this?
        while((USART1->ISR&USART_ISR_RXNE)!=USART_ISR_RXNE) {
            //Wait for RXNE flag to be set
        }
        char reader = USART1->RDR;//Read char from USART and put input_fifo with insert_echo_char()
        insert_echo_char(reader);
    }
    return fifo_remove(&input_fifo);//Remove char from input_fifo and return
    // REMEMBER TO NOT CHECK FOR NEWLINES WHEN line_mode IS NOT SET!
}

//=======================================================================
// IRQ invoked for USART1 activity.
void USART1_IRQHandler(void) {
    // Student code goes here...
    if ((USART1->ISR & USART_ISR_RXNE)) {//If RXNE flag is set
        char reader = USART1->RDR;//Read char from USART to insert_echo_char()
        insert_echo_char(reader);
    }
    if ((USART1->ISR & USART_ISR_TXE)) {//If TXE flag is set
        if (fifo_empty(&output_fifo)) {//If the FIFO is empty
            USART1->CR1 &= ~(USART_CR1_TXEIE);//Turn off TXEIE interrupt enable
            //FORGOT = IN THIS LINE ^
        }
        else {
            USART1->TDR = fifo_remove(&output_fifo);//Transmit char from output_fifo
        }
    }
    //-----------------------------------------------------------------
    // Leave this checking code here to make sure nothing bad happens.
    if (USART1->ISR & (USART_ISR_ORE|USART_ISR_NE|USART_ISR_FE|USART_ISR_PE)) {//removed USART_ISR_RXNE
        safe_printf("Problem in USART1_IRQHandler: ISR = 0x%x\n", USART1->ISR);
    }
    // REMEMBER TO REMOVE THE CKECK FOR USART_ISR_RXNE FROM THE WARNING
    // THAT INVOKES safe_printf().
}

// See lab document for description
static int getchar_irq(void) {
    // Student code goes here...
    if (line_mode == 1) {//check for \n only when line_mode == 1
        while(!fifo_newline(&input_fifo)) {//While input_fifo does not have \n
            asm("wfi");//Wait for an interrupt
        }
    }
    return fifo_remove(&input_fifo);//Return char removed from input_fifo

    // REMEMBER TO CHECK FOR A NEWLINE ONLY WHEN line_mode IS SET!
}

// See lab document for description
static int putchar_irq(char ch) {
    // Student code goes here...
    while (fifo_full(&output_fifo)) {//While output_fifo is full
        asm("wfi");//Wait for interrupt
    }
    if (ch == '\n') {//If 'ch' is a newline
        fifo_insert(&output_fifo, '\r');//Insert '\r' into output_fifo
    }
    else {
        fifo_insert(&output_fifo, ch);//insert ch into output_fifo
    }
    if ((USART1->CR1 & USART_CR1_TXEIE)!=USART_CR1_TXEIE) {//If TXE interrupt enable bit is not set
        USART1->CR1 |= USART_CR1_TXEIE;//Set TXEIE
        USART1_IRQHandler();//Call USART1_IRQHandler()
    }
    if (ch == '\n') {//If ch is '\n'
        while (fifo_full(&output_fifo)) {//while output_fifo is full
            asm("wfi");//wait for interrupt
        }
        fifo_insert(&output_fifo, '\n');//Insert '\n' in out_fifo
    }
    return ch;

}

//=======================================================================
// Called by the Standard Peripheral library for a write()
int __io_putchar(int ch) {
    if (interrupt_mode == INTR)
        return putchar_irq(ch);
    else
        return putchar_nonirq(ch);
}

//=======================================================================
// Called by the Standard Peripheral library for a read()
int __io_getchar(void) {
    if (interrupt_mode == INTR)
        return getchar_irq();
    else
        return getchar_nonirq();
}

void tty_init(void) {
    // Disable buffers for stdio streams.  Otherwise, the first use of
    // each stream will result in a *malloc* of 2K.  Not good.
    setbuf(stdin,0);
    setbuf(stdout,0);
    setbuf(stderr,0);

    // Student code goes here...
    RCC->AHBENR |= RCC_AHBENR_GPIOBEN;
    GPIOB->MODER &= ~(3<<12);//Reset//Change to PB6
    GPIOB->MODER &= ~(3<<14);//Reset//Change to PB7
    GPIOB->MODER |= (2<<12) | (2<<14);//Change to PB6 and PB7
    GPIOB->AFR[0] &= (0<<24) | (0<<28);//AF1 for PA9 and PA10//AF0 for PB6 and PB7
    RCC->APB2ENR |= RCC_APB2ENR_USART1EN;//Fairly sure we're using USART1
    USART1->CR1 &= ~USART_CR1_UE;//Disable USART
    USART1->CR1 &= ~(1<<28);//Configure USART for 8 bits
    USART1->CR1 &= ~USART_CR1_M;//M0. Helping to configure USART for 8 bits
    USART1->CR2 &= ~USART_CR2_STOP;//1 Stop bit
    USART1->CR1 &= ~USART_CR1_PCE;//no parity bit TODO:CHECK IF RIGHT
    USART1->CR1 &= ~USART_CR1_OVER8;//use 16x oversampling
    USART1->BRR = 48000000 / 230400;//Change to 230400//921600;//921600 baud rate
    USART1->CR1 |= USART_CR1_TE | USART_CR1_RE;//Enable USART to transmit and receive
    USART1->CR1 |= USART_CR1_UE;//Enable USART
    while(((USART1->ISR & USART_ISR_TEACK) != USART_ISR_TEACK) && ((USART1->ISR & USART_ISR_REACK) != USART_ISR_REACK)) {
    //while((USART_ISR_TEACK & USART1->ISR) == 0 || (USART1->ISR & USART_ISR_REACK) == 0) {
        //Wait for TEACK and REACK to be set
        //TODO: CHECK IF RIGHT
    }
    interrupt_mode = NON_INTR;//Set the 'interrupt_mode' variable to non_intr

    enable_tty_irq();//invoke enable_tty_irq()
    // REMEMBER TO CALL enable_tty_irq() HERE!
}

void raw_mode(void)
{
    line_mode = 0;
    echo_mode = 0;
}

void cooked_mode(void)
{
    line_mode = 1;
    echo_mode = 1;
}

int available(void)
{
    if (interrupt_mode == INTR) {
        if (fifo_empty(&input_fifo))
            return 0;
        return 1;
    } else {
        if ((USART1->ISR & USART_ISR_RXNE) == 0)
            return 0;
        return 1;
    }
}
