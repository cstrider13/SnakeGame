#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h> // for random()
#include "headers.h"

//Added my own health indicator
//int health = 100;
int high_score_money = 0;
char initials[4] = "a";//was 4

//Integer to know if it's time to move obstacles
int move_stuff = 0;//At 20, stuff should move. That's twice a second
int move_logs = 0;
int timer = 0;
int time = 60;
int high_score = 0;
int score = 0;
int lives = 5;
int num_goals_filled = 0;
int end1 = 0;
int end2 = 0;
int end3 = 0;
int end4 = 0;
int end5 = 0;

// The characters to be shown and their colors.
char scr[50][24];//Changed 80 to 50
char color[50][24];//Changed 80 to 50

// Data variables for the game...
int px;
int py;
int dx;
int dy;
int prevdx;
int prevdy;//I'll keep these for now
int money;
enum { SPLASH, RUNNING } phase = SPLASH;
int splash_ticks;

void init_obstacles() {//move the logs, turts and cars
    for(int row=1; row<28; row++) {
        if(row == 1) {//Far green end goal
            for(int x=1;x<19;x++) {
                if(x%4 != 0) {//If even. TODO:CHECK. Was x%2==0
                    color[x][row] |= 0x04;//Make background color dark blue
                }
                else {
                    color[x][row] = 0x02;//Make background color dark green
                }
            }
        } else if(row == 2 | row == 10) {//First log row
            for(int x=1;x<19;x++) {
                if((x>=3 & x<=6) | (x>=8 & x<=12) | (x>=15 & x<=18)) {color[x][row] = 0x08;}//make background brown
                else {color[x][row] = 0x04;}//make background dark blue
            }
        } else if(row == 3 | row == 9) {//First turtle
            for(int x=1;x<19;x++) {
                color[x][row] = 0x04;//make all background dark blue
                if((x>=1 & x<=2) | (x>=5 & x<=6) | (x>=11 & x<=12)| (x>=15 & x<=16)) {color[x][row] = 0x01;}//Make background red
                else {color[x][row] = 0x04;}//make background dark blue
            }
        } else if(row == 4 | row == 8) {//Second logs
            for(int x=1;x<19;x++) {
                if((x>=1 & x<=4) | (x>=7 & x<=13) | (x>=16 & x<=18)) {color[x][row] = 0x08;}//Make background brown
                else {color[x][row] = 0x04;}//make background dark blue
            }
        } else if(row == 5 | row == 7) {//Second turtles
            for(int x=1;x<19;x++) {
                color[x][row] = 0x04;//make all background dark blue
                if((x==1) | (x>=3 & x<=5) | (x>=7 & x<=9) | (x>=11 & x<=13) | (x>=15 & x<=17)) {color[x][row] = 0x01;}//Make background red
                else {color[x][row] = 0x04;}//make background dark blue
            }
        } else if(row == 6) {//final logs
            for(int x=1;x<19;x++) {
                if((x>=2 & x<=4) | (x>=8 & x<=10) | (x>=14 & x<=16)) {color[x][row] = 0x08;}//Make background brown
                else {color[x][row] = 0x04;}//make background dark blue
            }
        } else if(row == 11 | row == 22) {//purple safe zones
            for(int x=1;x<19;x++) {
                color[x][row] = 0x05;//make background purple
                //Was 0x05. Using to test colors
            }
        } else if(row == 12 | row == 17) {//Blue truck
            for(int x=1;x<19;x++) {
                if((x>=4 & x<=5) | (x>=16 & x<=17)) {color[x][row] = 0x0c;}//Make background light blue
                else {color[x][row] = 0x00;}//make background black
            }
        } else if(row == 13 | row == 18) {//White car
            for(int x=1;x<19;x++) {
                if((x==1) | (x==11)) {color[x][row] = 0x0f;}//Make background white
                else {color[x][row] = 0x00;}//make background black
            }
        } else if(row == 14 | row == 19) {//Pink car
            for(int x=1;x<19;x++) {
                if((x==2) | (x==10) | (x==15)) {color[x][row] = 0x0d;}//Make background pink
                else {color[x][row] = 0x00;}//make background black
            }
        } else if(row == 15 | row == 20) {//Cyan car
            for(int x=1;x<19;x++) {
                if((x==3) | (x==11)) {color[x][row] = 0x0e;}//Make background pink
                else {color[x][row] = 0x00;}//make background black
            }
        } else if(row == 16 | row == 21) {//Red car
            for(int x=1;x<19;x++) {
                if((x==1) | (x==8) | (x==13)) {color[x][row] = 0x09;}//Make background pink
                else {color[x][row] = 0x00;}//make background black
            }
        }
    }
}

// Print a message at screen coordinate x,y in color c.
void msg(int x, int y, int c, const char *s)
{
  int n;
  int len = strlen(s);
  for(n=0; n<len && n+x<50; n++) {//Changed 80 to 50
    color[x+n][y] = c;
    scr[x+n][y] = s[n];
  }
}

void time_update() {//My health indicator function
    time--;
    char buf[10];//Reduced from 30
    sprintf(buf, "Time:%d", time);
    msg(21,1, 0xe0, buf);//was 0xe0
    if (time < 10) {
        msg(27,1,0x00," ");//clear so it's not saying
    }
}

// Check two points, (x1,y1) and (x2,y2) and return a 1
// if they are within 5 character cells of each other.
int tooclose(int x1, int y1, int x2, int y2)
{
  int x = x1 - x2;
  int y = y1 - y2;
  if (x*x + y*y < 25)
    return 1;
  return 0;
}

// Indicate a collision with a big red X.
// Also display a "Game over" statement.
void collision(void)
{
  msg(px,py,0x90, "X");
  //I'm making sure the collision markings don't go out of bounds
  if (px-1 >= 0 && py-1 >= 0) {
      msg(px-1,py-1,0x90, "\\");
  }
  if (px+1 <= 19 && py-1 >= 0) {//change 61 to 19
      msg(px+1,py-1,0x90, "/");
  }
  if (px+1 <= 19 && py+1 <= 23) {//change 61 to 19
      msg(px+1,py+1,0x90, "\\");
  }
  if (px-1 >= 0 && py+1 <= 23) {
      msg(px-1,py+1,0x90, "/");
  }
  if (py > 12) {
    msg(30,8, 0x0f, "   Game over   ");
    msg(30,9, 0x0f, " Press any key ");
  } else {
    msg(30,15, 0x0f,"   Game over   ");
    msg(30,16, 0x0f," Press any key ");
  }
}

// Initialize the game data structures.
void init(void)
{
  time = 60;//restart time
  int x,y;
  for(y=0; y<24; y++)
    for(x=0; x<20; x++) {//Change x<62 to x<20
      scr[x][y] = ' ';
      color[x][y] = 0xf0;
    }

  for(x=0; x<20; x++) {//Change x<62 to x<20
    if (x==0 || x==19) {//Change x==61 to x==19
      msg(x,0,0xb0,"+");
      msg(x,23,0xb0,"+");
    } else {
      msg(x,0,0xb2,"-");//change color from 0xb0 to 0xb2
      msg(x,23,0xb2,"-");
    }
  }
  for(y=1; y<23; y++) {
    msg(0,y, 0xb0, "|");
    msg(19,y, 0xb0, "|");//Change 61 to 19
  }

  init_obstacles();//Set up the screen

  px=9;//40;
  py=22;//TODO: change back to 22. Change to 11 for testing logs
  scr[px][py] = 'P';//'@';
  color[px][py] |= 0x30;//Gold//0xa0; I changed it to |= so it wouldn't erase starting purple tile

  //char buf1[30];//Initialize the text
  msg(21,22,0xe0,"Lives:");
  msg(28,22,0x00,"      ");//Erase space where previous lives were so you don't see more lives than you have
  for(int l=0;l<lives;l++) {
      msg(28+l,22,0x30,"P");//5 lives
  }
  msg(26,11,0x00,"  ");//Erase the extra stuff in time because apparently, it can mess up
  msg(21,11,0xe0,"Time:60");
  msg(21,0,0xe0,"Score");
  msg(35,0,0xe0,"High Score");
  msg(21,1,0x00,"          ");//erase score so it doesn't overwrite weird
  msg(35,1,0x00,"          ");//erase score so it doesn't overwrite weird
  char buf[10] = "";
  sprintf(buf,"%d",score);
  msg(21,1,0x10,buf);
  char buf1[10] = "";
  sprintf(buf1,"%d",high_score);
  msg(35,1,0x10,buf1);


  //TODO: Erase splash screen
  msg(30,8, 0x00, "                 ");
  msg(30,9, 0x00, "                 ");
  msg(30,10,0x00, "                 ");
  msg(30,11,0x00, "                 ");
  //Erase collision thing
  msg(30,8, 0x00, "               ");
  msg(30,9, 0x00, "               ");
  msg(30,15, 0x00,"               ");
  msg(30,16, 0x00,"               ");

  msg(35,2,0x00,"               ");//Erase "new high score"
  msg(21,2,0x00,"     ");//Erase 1-UP!

  //TODO: Make sure I don't erase a frog if it's supposed to stay in the end
  if(end1==1) {
      scr[2][1] = 'P';
      color[2][1] = 0x34;
  }
  if(end2==1) {
      scr[6][1] = 'P';
      color[6][1] = 0x34;
  }
  if(end3==1) {
      scr[10][1] = 'P';
      color[10][1] = 0x34;
  }
  if(end4==1) {
      scr[14][1] = 'P';
      color[14][1] = 0x34;
  }
  if(end5==1) {
      scr[17][1] = 'P';
      color[17][1] = 0x34;
  }
}

// Dump the scr and color arrays to the terminal screen.
void render(void)
{
  int x,y;
  home();
  int col = color[0][0];
  fgbg(col);
  for(y=0; y<24; y++) {
    setpos(0,y);
    for(x=0; x<50; x++) {//changed 80 to 50
      if ((scr[x][y] == 'P') & (scr[x+1][y] != 'r')) {color[x][y] |= 0x30;}//Make sure frog is visible
      if (color[x][y] != col) {
        col = color[x][y];
        fgbg(col);
      }
      putchar(scr[x][y]);
    }
  }
  fflush(stdout);
}

// Display the initial splash screen.
void splash(void)
{
  clear();
  int x,y;
  for(y=0; y<24; y++)
    for(x=0; x<50; x++) {//changed 80 to 50
      scr[x][y] = ' ';
      color[x][y] = 0x70;
    }
  msg(30,8, 0x0a, "                 ");
  msg(30,9, 0x0a, "     Frogger     ");
  msg(30,10,0x0a, "  Press Any Key  ");
  msg(30,11,0x0a, "                 ");
  render();
}

//TODO: Make end goal function
void end_goal() {
    //TODO: Reset position to starting point
    //If the whole row is filled in... I guess you win?
    if((px>=1 & px<=3) & (end1==0)) {//end1
        end1 = 1;//Shows that this has been filled
        //TODO:FINISH XXXXXXXXXXXXXXXXXXXXXXXXXXX
    } else if((px>=5 & px<=7) & (end2==0)) {//end2
        end2 = 1;
    } else if((px>=9 & px<=11) & (end3==0)) {//end3
        end3 = 1;
    } else if((px>=13 & px<=15) & (end4==0)) {//end4
        end4 = 1;
    } else if(px>=17 & (end5==0)) {//end5
        end5 = 1;
    } else {//If frog isn't in empty space
        return;
    }
    num_goals_filled++;
    if(num_goals_filled == 5) {//Was 9
        end1=0;end2=0;end3=0;end4=0;end5=0;//TODO:Is this okay?
        lives++;//1-UP!
        msg(21,2,0x10,"1-UP!");
        for(int x=1;x<19;x++) {//TODO:Erase the things
            if(x%4 != 0) {//Was x%2 != 0
                color[x][1] = 0x02;
                scr[x][1] = ' ';//Get rid of frog
            }
        }
        score += 500;//TODO:Adjust score?
    }
    score += time;
    init();//Reset the stage. TODO: Check
}

void game_over() {//function that handles what happens when you run out of lives
    //TODO: DO I need to write anything here or will it be taken care of in init?
    if(score > high_score) {
        high_score = score;
        msg(35,2,0x10,"New High Score!");//erase score so it doesn't overwrite weird
        char buf[10];
        sprintf(buf,"%d",high_score);
        msg(35,1,0x10,buf);
    }
    score = 0;//Reset score
    lives = 5;//Reset lives
}

void lose_life() {//Function to reduce life of frog
    lives--;
    if(lives == 0) {
        collision();
        game_over();
    }
    else {
        msg(px,py,0x90, "X");
        //I'm making sure the collision markings don't go out of bounds
        if (px-1 >= 0 && py-1 >= 0) {
            msg(px-1,py-1,0x90, "\\");
        }
        if (px+1 <= 19 && py-1 >= 0) {//change 61 to 19
            msg(px+1,py-1,0x90, "/");
        }
        if (px+1 <= 19 && py+1 <= 23) {//change 61 to 19
            msg(px+1,py+1,0x90, "\\");
        }
        if (px-1 >= 0 && py+1 <= 23) {
            msg(px-1,py+1,0x90, "/");
        }
        if (py > 12) {
          msg(30,8, 0x0f, "   Life Lost   ");
          msg(30,9, 0x0f, " Press any key ");
        } else {
          msg(30,15, 0x0f,"   Life Lost   ");
          msg(30,16, 0x0f," Press any key ");
        }
    }
    if(time != 0) {
        render();//Breaks if timer is at 0
    }
    phase = SPLASH;
    splash_ticks=0;
    //render();
    //todo: consider waiting for a second or two
    //init();//TODO:Figure out what I should do this
}


//Make the background move
void move_obstacles(void) {
    for(int r=1;r<23;r++) {
        if(((r==2)|(r==4)|(r==6)|(r==8)|(r==10)) & (move_logs == 1)) {//LOGS
            int holder = 0x04;
            for(int x=18; x>0; x--) {//1;x<19;x++) {
                //if(x==19) {x=1;}//Need to begin at 1
                if((color[x][r] == 0x08) | (color[x][r] == 0x38)) {//If square is brown or frog is on log
                    if(x==18) {//Wrap around
                        holder = color[x][r];
                        //color[1][r] = 0x08;
                    } else {//Make square to right brown
                        color[x+1][r] = 0x08;
                    }
                    if((scr[x][r] == 'P') & (color[x-1][r] != 0x08) & (x==18)) {//If frog is going to fall off the log
                        //TODO:Check. Changed color[x][r] == 0x38 to scr[x][r] == 'P'
                        lose_life();
                    } else if((scr[x][r] == 'P') & (x!=18)) {//If frog is on moving log and won't fall off
                       //TODO:Check. Changed color[x][r] == 0x38 to scr[x][r] == 'P'
                        scr[px][py] = ' ';//remove frog
                        color[px][py] = 0x08;//Recolor the foreground
                        px += 1;//Change px to be one to the right
                        scr[px][py] = 'P';//Put frog in new space
                        color[px][py] = 0x38;//color the frog gold
                    } //TODO: I don't think I need to account for it the frog is at wall but won't fall
                    color[x][r] = 0x04;//Replace with dark blue
                }
                //if(x==1) {x=19;}//Reset so it'll work
                if(x==1) {color[x][r] = holder;}
            }
        } else if(((r==3)|(r==5)|(r==7)|(r==9)) & (move_logs == 1)) {//TURTLES
            int holder = 0x04;
            for(int x=1;x<19;x++) {
                if((color[x][r] == 0x01) | (color[x][r] == 0x31)) {//If square is red or frog is on turtle
                    if(x==1) {
                        holder = color[x][r];
                        //color[18][r] = 0x01;
                    }//Wrap around
                    else {
                        color[x-1][r] = 0x01;
                    }//Make square to left red

                    if((color[x][r] == 0x31) & (color[x+1][r] != 0x01) & (x==1)) {//If frog is going to fall off the turtle
                        lose_life();
                    } else if((color[x][r] == 0x31) & (x!=1)) {//If frog is on moving log and won't fall off
                        scr[px][py] = ' ';//remove frog
                        color[px][py] = 0x01;//Recolor the foreground
                        px -= 1;//Change px to be one to the left
                        scr[px][py] = 'P';//Put frog in new space
                        color[px][py] = 0x31;//color the frog gold
                    }
                    color[x][r] = 0x04;//Remove red
                }
                if(x==18) {color[x][r] = holder;}
            }
        } else if((r==12)|(r==14)|(r==16)|(r==17)|(r==19)|(r==21)) {//LEFT MOVING VEHICLES
            int holder = 0x00;
            for(int x=1;x<19;x++) {
                if((color[x][r]==0x0c)|(color[x][r]==0x0f)|(color[x][r]==0x0d)|(color[x][r]==0x0e)|(color[x][r]==0x09)) {//If square has car in it
                    if(x==1) {//Wrap around
                        holder = color[x][r];
                        //color[18][r] = color[x][r];//1][r];
                        if(scr[18][r] == 'P') {//If frog was at the point that the car was going to spawn in
                            color[18][r] |= 0x30;//Color the frog
                            lose_life();
                        }
                    }
                    else {//Make square to left red
                        color[x-1][r] = color[x][r];
                        if(scr[x-1][r] == 'P') {//If frog was at the point that the car was going to spawn in
                            color[x-1][r] |= 0x30;//Color the frog
                            lose_life();
                        }
                    }
                    color[x][r] = 0x00;//Remove color and make black
                }
                if(x==18) {color[x][r] = holder;}
            }
        } else if((r==13)|(r==15)|(r==18)|(r==20)) {//RIGHT MOVING VEHICLES
            int holder = 0x00;
            for(int x=18; x>0; x--) {
                if((color[x][r]==0x0c)|(color[x][r]==0x0f)|(color[x][r]==0x0d)|(color[x][r]==0x0e)|(color[x][r]==0x09)) {//If square has car in it
                    if(x==18) {//Wrap around
                        holder = color[x][r];
                        //color[1][r] = color[x][r];//18][r];
                        //render();
                        if(scr[1][r] == 'P') {//If frog was at the point that the car was going to spawn in
                            color[1][r] |= 0x30;//Color the frog
                            lose_life();
                        }
                    }
                    else {//Make square to left red
                        color[x+1][r] = color[x][r];
                        if(scr[x+1][r] == 'P') {//If frog was at the point that the car was going to spawn in
                            color[x+1][r] |= 0x30;//Color the frog
                            lose_life();
                        }
                    }
                    color[x][r] = 0x00;//Remove color and make black
                }
                if(x==1) {color[x][r] = holder;}
            }
        }
    }
}

void update_time(void) {
    time--;
    char buf[10];
    sprintf(buf,"Time:%d",time);
    msg(21,11,0x00,"       ");
    msg(21,11,0xe0,buf);
    if(time==0) {
        lose_life();
    }
}

// Move the snake into the new position.
// And erase the last character of the tail.
void move(void)
{
    scr[px][py] = 'P';//'@'; // draw new head
    color[px][py] |= 0x30;//Gold//TODO: Check. Added | to =
}

// Interpret a key press and update the data structures.
void update(char in)
{
  prevdx = dx;
  prevdy = dy;
  switch(in) {
    case 'a':
    //case 68://left
    case 'h': dx=-1; dy=0; break;
    case 's':
    //case 66://down
    case 'j': dx=0; dy=1; break;
    case 'w':
    //case 65://up
    case 'k': dx=0; dy=-1; break;
    case 'd':
    //case 67://right
    case 'l': dx=1; dy=0; break;
    case ' ': return;//Added case for if the user has input nothing yet
    default: dx=1; dy =1; break;
  }

  scr[px][py] = ' ';
  color[px][py] &= (0x0f);//Erase the foreground color


  if((px+dx != 0) & (px+dx !=19)) {px += dx;}//Update position if it's not into a wall
  if((py+dy != 0) & (py+dy !=23)) {py += dy;}//Update position if it's not into a wall

  if (color[px][py] == 0x05) {//If at a safe zone
    move();//Just move the token
  } else if ((color[px][py] != 0x00) & ((py>=12) & (py<=21))) {//If run into vehicle
    lose_life();
  } else if ((color[px][py] == 0x04) & ((py>=2) & (py<=10))) {//If fall into water
    lose_life();
  } else if ((color[px][py] == 0x04) & (py==1)) {//If get to empty end goal
    move();
    end_goal();
  } else if (color[px][py] == 0x00) {//If on the road
    move();
  } else if ((color[px][py] == 0x08) | ((color[px][py] == 0x01) & (py<11))) {//If on log or turtle
    move();
  } else {
    move();//Check
  }
}

void animate(void)
{
  if (phase == SPLASH) {
    if (splash_ticks < 10) {
      while (available())
        getchar();
      splash_ticks++;
      return;
    }
    // Stall waiting for a key.
    while (!available())
      ;
    getchar();
    // Get the timer counter value for the random seed.
    int seed=get_seed();
    srandom(seed);
    init();
    clear();
    phase = RUNNING;
  }
  char in=' ';
  if (phase == RUNNING) {
    if(move_stuff == 2) {
        move_logs = 1;
        move_obstacles();
        move_stuff = 0;
        move_logs = 0;
        render();
    } else if(move_stuff == 1) {
        move_obstacles();
        move_stuff++;
        render();
    } else {move_stuff++;}

    while(available()) {
      in = getchar();
    }
    if (in == 'q') {
#ifdef __linux__
      cursor_on();
      cooked_mode();
      exit(0);
#else
      splash();
      render();
      phase = SPLASH;
      splash_ticks = 0;
#endif
    }
    if (in == 'p') {
      freeze();
    }
    /*if (in == 27) {//Added to accommodate arrow keys for Nathan
        while(available()) {
          in = getchar();
        }
        if(in == 91) {
            while(available()) {
              in = getchar();//Get actual code thing
            }
        }
    }*/
    update(in);
    render();
    return;
  }
}
